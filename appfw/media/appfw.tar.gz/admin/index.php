<?php

 #
 # MiniFW 3
 #
 # indítás
 #

header("Refresh:0; url=../index.php?admin=a");


?>
