<?php

 #
 # MiniFW 3
 #
 # template
 #



class mini{
  # verzió adatok
  public $TEMP_VERSION="0";
  public $TEMP_TITLE="appfw";
  # include files
  public $TEMP_FAVICON="";
  public $TEMP_JS="template.js";
  public $TEMP_CSS="template.css";
  public $TEMP_DIR="";


  function __construct($t="",$fi="",$td=""){
    $this->TEMP_TITLE=$t;
    $this->TEMP_FAVICON=$fi;
    $this->TEMP_DIR=$td;
  }



  # cím beállítás
  function title($t,$fi,$td){
    $this->TEMP_TITLE=$t;
    $this->TEMP_FAVICON=$fi;
    $this->TEMP_DIR=$td;
  }



  # fejrész
  function pagehead(){
    echo("<!DOCTYPE html>\n");
    echo("<html lang=\"hu\">\n");
    echo("<head>\n");
    echo("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n");
    echo("<title>$this->TEMP_TITLE</title>\n");
    echo("<link rel=\"icon\" type=\"image/x-icon\" href=\"$this->TEMP_FAVICON\" >\n");
    echo("<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"$this->TEMP_FAVICON\" >\n");
    echo("<meta name=\"robots\" content=\"noindex, nofollow, noarchive\" />\n");
    echo("<meta name=\"referrer\" content=\"strict-origin-when-cross-origin\" />\n");
    echo("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n");
    # css és js
    echo("<style>\n");
    $fc=$this->TEMP_DIR."/".$this->TEMP_CSS;
    if (file_exists($fc)){
      include($fc);
    }
    echo("</style>\n");
    echo("</head>\n");
	echo("<body>\n");
    echo("<script>\n");
    $fc=$this->TEMP_DIR."/".$this->TEMP_JS;
    if (file_exists($fc)){
      include($fc);
    }
    echo("</script>\n");
	//echo($this->TEMP_FAVICON);
  }



  # lap lezárás
  function pageend(){
    echo("</body>\n");
    echo("</html>\n");
  }



  # fejrész
  function header(){
    global $fwapp;

    echo("<div class=all-page>");
    echo("<header>\n");
    echo("<div class=\"menu\">");
    echo("<ul class=\"sidenav\">");
    foreach($fwapp->APP_MENU as $l){
      echo("<li><a class=\"aactive\" href=\"?$l[1]\">$l[0]</a></li>");
    }
    echo("</ul>");
    echo("</div>");
    echo("</header>\n");
    echo("<div class=\"content\">");
  }



  # lábrész
  function footer(){
    global $fwcfg,$fwapp,$fwlang;

    echo("</div>\n");
    echo("<footer>\n");
    echo("<div class=\"menu\">");
    echo("<ul class=\"sidenav\">");
    echo("<li class=\"lileft\"><a>$fwapp->APP_COPYRIGHT</a></li>");
    if ($fwcfg->FW_ADMIN_MODE){
      echo("<li class=\"liright\"><a href=\"?\">");
      echo($fwlang->lang("Kilépés"));
      echo("</a></li>");
    }else{
      echo("<li class=\"liright\"><a href=\"?$fwcfg->FW_ADMIN_LINK=x\">");
      echo($fwlang->lang("Belépés"));
      echo(" [ ".$fwcfg->FW_ADMIN_LINK." ]");
      echo("</a></li>");
    }
    echo("</ul>");
    echo("</div>\n");
    echo("</footer>");
  }



}


?>
