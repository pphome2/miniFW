<?php

 #
 # MiniFW 3
 #
 # app indító
 #



class fw_search{


  function ___construct(){}
  function ___destruct(){}


}

?>
