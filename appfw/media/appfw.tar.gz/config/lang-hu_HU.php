<?php

 #
 # MiniFW 3
 #
 # nyelvi fájl
 #



$FW_LANG=array(
            "Beállítások"=>"Beállítások",
            "Felhasználónév"=>"Felhasználónév",
            "Jelszó"=>"Jelszó",
            "Mehet"=>"Mehet",
            "Kilépés beállításokból"=>"Kilépés beállításokból",
            "Kilépés"=>"Kilépés",
            "Felhasználók"=>"Felhasználók",
            "Paraméterek"=>"Paraméterek",
            "Mentés"=>"Mentés",
            "Felhasználók"=>"Felhasználók",
            "ID"=>"ID",
            "Név"=>"Név",
            "Szerepkör"=>"Szerepkör",
            "Információ"=>"Információ",
            "Törlés / Módosítás"=>"Törlés / Módosítás",
            "Utolsó"=>"Utolsó",
            "Első"=>"Első",
            "Érték"=>"Érték",
            "Mentés indítása"=>"Mentés indítása",
            "SQL mentés letöltése"=>"SQL mentés letöltése",
            "Fájlmentés letöltése"=>"Fájlmentés letöltése",
            "Telepítő program letöltése"=>"Telepítő program letöltése",
            "Korábbi mentés"=>"Korábbi mentés",
            "Mentésfájlok törlése"=>"Mentésfájlok törlése",
            "A törlés megtörtént"=>"A törlés megtörtént",
            "Mentés indítása"=>"Mentés indítása",
            "Paraméter"=>"Paraméter",
            "Módosítás"=>"Módosítás",
            "Törlés"=>"Törlés",
            "Vissza"=>"Vissza",
            "Adattárolás megtörtént"=>"Adattárolás megtörtént",
            "Adattörlés megtörtént"=>"Adattörlés megtörtént",
            "Felhasználó"=>"Felhasználó",
            "Leírás"=>"Leírás",
            "Hiba a törlés közben"=>"Hiba a törlés közben",
            "Másolási hiba"=>"Másolási hiba",
            "Hiba történt"=>"Hiba történt",
            ""=>""
          );



?>
