<?php

 #
 # MiniFW 3
 #
 # nyelvi fájl
 #



$FW_LANG=array(
            "első"=>"első sor",
            ""=>""
          );



?>
