<?php

 #
 # MiniFW 3
 #
 # indítás
 #

if (file_exists("load.php")){
  include("load.php");
}

?>
