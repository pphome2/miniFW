<?php


if (file_exists("./public/index.php")){
    include("./public/index.php");
}


?>
