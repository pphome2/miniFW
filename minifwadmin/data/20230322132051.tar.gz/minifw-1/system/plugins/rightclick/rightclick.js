<script type="text/javascript">

	window.oncontextmenu = function() {return false;}

	document.onselectstart = function() {return false;}
	document.onmousedown = disableselect

</script>
