<script>

function pricetabclick(formname,inputname,mname){
	document.getElementById(inputname).value=mname;
	document.getElementById(formname).submit();
	return false;
}

</script>

