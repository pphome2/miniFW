<?php

 #
 # Load common config file
 #
 # info: main folder copyright file
 #
 #



?>
