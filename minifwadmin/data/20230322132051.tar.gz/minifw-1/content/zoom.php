<?php

echo("<div class=spaceline50></div>");
echo("<div class=spaceline50></div>");


if (isset($IMGZOOM)){
	imgzoom("../content/img/1.jpg","Első kép","Kép megjelenítése 1");
	imgzoom("../content/img/2.jpg","Második kép","Kép megjelenítése 2");
	imgzoom("../content/img/3.jpg","Harmadik kép","Kép megjelenítése 3");
	imgzoom("../content/img/3.jpg","Harmadik kép","");
}


echo("<div class=spaceline50></div>");
echo("<div class=spaceline50></div>");


?>
