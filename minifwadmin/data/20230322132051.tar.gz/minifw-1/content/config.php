<?php

if (file_exists("$SYS_CONTENT_DIR/data/config.php")){
	include("$SYS_CONTENT_DIR/data/config.php");
    }

?>
