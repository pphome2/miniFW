<?php

 #
 # Local config file - demo
 #
 # info: main folder copyright file
 #
 #

# configuration - need change it
# change from sysconfig.sys

$SYS_COPYRIGHT="© 2020. <a href=https://github.com/pphome2/minifw>MiniFW</a>";
$SYS_DEVELOPER="<a href=\"mailto:wswdteam@gmail.com\">WSWDTeam</a>";

# need md5 passcode: password
$SYS_ADMIN_PASS="5f4dcc3b5aa765d61d8327deb882cf99";

$SYS_SITENAME="MiniFW - example.com";
$SYS_SITE_HOME="http://www.example.com";

$LANGUAGE=$SYS_CONTENT_DIR."data/lang.hu";
$SYS_PRIVACY_POLICY=$SYS_CONTENT_DIR."privacy.php";

#$SYS_META=array("");


# local site config

$LOCAL_CSS=$SYS_CONTENT_DIR."css/site.css";
$LOCAL_JS_BEGIN="";
$LOCAL_JS_END="";
$LOCAL_HEADER=$SYS_CONTENT_DIR."header.php";
$LOCAL_FOOTER=$SYS_CONTENT_DIR."footer.php";



?>
