<script>

function delrow(obj){
	obj2=obj.parentNode;
	obj2.parentNode.style.display='none';
}

</script>
