<?php

 #
 # MiniApps - framework
 #
 # info: main folder copyright file
 #
 #

# app zone
$L_SITENAME="Demo";
$L_ROOTHOME="Google search";
$L_SITEHOME="Demo page";

# system zone
$L_THEME="Next theme";
$L_PRIVACY_MENU="Privacy";
$L_PASS="Access code";
$L_BUTTON_NEXT="Next";
$L_LOGOUT="Logout";
$L_PRINT="Print";
$L_BACKPAGE="Go back";
$L_JUMP="Go next page";
$L_SEARCH="Search";
$L_NO_AVAILABLE="This fuunction not available.";

# cookie
$L_COOKIE_TEXT="The site use cokies. Please read the Privacy page.";
$L_PRIVACY_HEADER="Privacy page address";

?>
