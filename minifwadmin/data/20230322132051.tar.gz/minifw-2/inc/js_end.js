<script>

var eid = document.getElementById("esysmessage");
if (eid){
    setTimeout(function(){
        eid.style.display = "none";
    }, 12000);
}

var wid = document.getElementById("wsysmessage");
if (wid){
    setTimeout(function(){
        wid.style.display = "none";
    }, 11000);
}

var oid = document.getElementById("osysmessage");
if (oid){
    setTimeout(function(){
        oid.style.display = "none";
    }, 10000);
}

var iid = document.getElementById("isysmessage");
if (iid){
    setTimeout(function(){
        iid.style.display = "none";
    }, 13000);
}

</script>
