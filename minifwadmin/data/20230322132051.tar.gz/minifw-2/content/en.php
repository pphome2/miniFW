<?php

 #
 # MiniApps - Demo language
 #
 # info: main folder copyright file
 #
 #

# rendszer
$L_SITENAME="Demo";
$L_ROOTHOME="Intranet";
$L_SITEHOME="Demo app";

# applikáció
$I_MENU=array("Demo page","","","");

?>
