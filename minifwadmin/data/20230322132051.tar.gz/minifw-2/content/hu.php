<?php

 #
 # MiniApp
 #
 # info: main folder copyright file
 #
 #

# rendszer
$L_SITENAME="Iktatás";
$L_ROOTHOME="Intranet";
$L_SITEHOME="Demo program";

# applikáció
$D_TITLE="Demo";
$D_MENU=array("Demo menü","","","");

?>

