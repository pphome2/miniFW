<?php

 #
 # MiniApp
 #
 # info: main folder copyright file
 #
 #

$I_MENUCODE=array("n");

# app menu
$MA_MENU=array(
        array($I_MENU[0],$I_MENUCODE[0])
            );
$MA_ADMINMENU=array(
        #array($L_MENU2,"list.php")
            );

$I_SEPARATOR="|";

?>
