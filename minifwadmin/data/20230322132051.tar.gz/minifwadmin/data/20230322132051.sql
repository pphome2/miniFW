delete from mfw_users;
insert into mfw_users (id,name,pass,role,email,comm) values ("1","admin","e3274be5c857fb42ab72d786e281b4b8","","","");
delete from mfw_params;
insert into mfw_params (id,name,data) values ("2023032109403363082","10","wereee552");
insert into mfw_params (id,name,data) values ("2023032109403363083","10","wereee552");
insert into mfw_params (id,name,data) values ("2023032109403363281","10","wereee");
